NANDLAL KUMAR — ONLINE SERVICES WEBSITE
========================================

Files:
- index.html: Main website content
- style.css: Responsive design
- script.js: Mobile menu and demo contact form

HOW TO PREVIEW
1. Extract the ZIP file.
2. Open index.html in a browser (Chrome recommended).

HOW TO PUBLISH FREE
- GitHub Pages: create a repository, upload these files to the repository root, then enable Pages in repository Settings.
- Netlify: sign in, then drag the extracted project folder into Netlify's manual deploy area.

IMPORTANT
- This is a static front-end starter template. The contact form does not store or send data to a server.
- To enable WhatsApp, open script.js and replace the empty whatsappNumber value with your WhatsApp number including country code (digits only, e.g. 91XXXXXXXXXX).
- The site is a private information/help template, not an official government website. Do not collect Aadhaar numbers, OTPs, bank details, or other sensitive data in this demo.
- Verify all service details and official links before publishing.
