const menuToggle = document.getElementById('menuToggle');
const navMenu = document.getElementById('navMenu');

menuToggle.addEventListener('click', () => {
  const open = navMenu.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
  menuToggle.textContent = open ? '×' : '☰';
});

navMenu.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    navMenu.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.textContent = '☰';
  });
});

document.getElementById('year').textContent = new Date().getFullYear();

document.querySelectorAll('[data-service]').forEach(link => {
  link.addEventListener('click', () => {
    const service = link.getAttribute('data-service');
    document.getElementById('service').value = service;
  });
});

document.getElementById('contactForm').addEventListener('submit', event => {
  event.preventDefault();
  const name = document.getElementById('name').value.trim();
  const service = document.getElementById('service').value;
  const message = document.getElementById('message').value.trim();
  const text = `नमस्ते, मेरा नाम ${name} है। मुझे ${service} के बारे में जानकारी चाहिए। सवाल: ${message}`;
  document.getElementById('formStatus').textContent =
    'संदेश तैयार हो गया है। इस डेमो में संदेश भेजा नहीं गया। WhatsApp सुविधा जोड़ने के लिए script.js में अपना नंबर सेट करें।';
  // To enable WhatsApp, replace the placeholder below with your WhatsApp number including country code.
  const whatsappNumber = '';
  if (whatsappNumber) {
    window.open(`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(text)}`, '_blank', 'noopener');
  } else {
    console.log('Contact message draft:', text);
  }
});
